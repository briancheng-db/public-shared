# Databricks notebook source

# COMMAND ----------

dbutils.widgets.text("catalog_schema", "shared.workspace_inventory")
# COMMAND ----------
catalog_schema = dbutils.widgets.get("catalog_schema")
# COMMAND ----------
from pyspark.sql.functions import col, regexp_extract, explode, from_json
from pyspark.sql.types import StructType, StructField, StringType, ArrayType

def transform_members_data(groups_data_df):
    # Define the schema for a single member struct
    member_schema = StructType([
        StructField("display", StringType(), True),
        StructField("$ref", StringType(), True),
        StructField("value", StringType(), True)
    ])

    # Define the schema for the array of member structs
    members_schema = ArrayType(member_schema)

    # Parse the JSON string into an array of structs
    parsed_df = groups_data_df.select(
        col("displayName").alias("groupName"),
        from_json(col("members"), members_schema).alias("members_array")
    )

    # Explode the array to create individual rows for each member
    exploded_df = parsed_df.select(
        col("groupName"),
        explode("members_array").alias("member")
    )

    # Extract the required fields from the member struct
    transformed_df = exploded_df.select(
        col("groupName"),
        col("member.display").alias("displayName"),
        regexp_extract(col("member.$ref"), r"^([^/]+)", 1).alias("type"),
        col("member.value").alias("ID")
    )

    return transformed_df

# COMMAND ----------
sql = f"""
    select
        *
    from {catalog_schema}.groups
    """
groups_data_df = spark.sql(sql)

# Transform the data
result_df = transform_members_data(groups_data_df)
# enable schema evolution mergeSchema=True
result_df.write.option("mergeSchema", "true").mode("overwrite").saveAsTable(f"{catalog_schema}.group_members")
