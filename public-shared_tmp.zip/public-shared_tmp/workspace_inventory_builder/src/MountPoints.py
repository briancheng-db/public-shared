# Databricks notebook source
%pip install --upgrade databricks-sdk
dbutils.library.restartPython()
# COMMAND ----------

dbutils.widgets.text("catalog_schema", "shared.workspace_inventory")

catalog_schema = dbutils.widgets.get("catalog_schema")
# COMMAND ----------
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import current_timestamp

# Get mount points
# Ref: https://docs.databricks.com/aws/en/dev-tools/databricks-utils#dbutils-fs
mountPoints = dbutils.fs.mounts()

# Define schema
schema = StructType([
    StructField("mountPoint", StringType(), True),
    StructField("source", StringType(), True),
    StructField("encryptionType", StringType(), True)
])

# Convert mount data to list of tuples
data = [(mount.mountPoint, mount.source, mount.encryptionType) for mount in mountPoints]
df = spark.createDataFrame(data, schema)

df = df.withColumn("updated_at", current_timestamp())

df.write.option("mergeSchema", "true").mode("overwrite").saveAsTable(f"{catalog_schema}.workspace_mount_points")

# COMMAND ----------
