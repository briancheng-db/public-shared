# Databricks notebook source
%pip install --upgrade databricks-sdk
dbutils.library.restartPython()
# COMMAND ----------
dbutils.widgets.removeAll()
# COMMAND ----------
dbutils.widgets.text("max_depth", "3")
dbutils.widgets.text("catalog_schema", "shared.bigc")
# COMMAND ----------
widgets = dbutils.widgets.getAll()
max_depth = int(widgets["max_depth"])
catalog_schema = widgets["catalog_schema"]
print(f"Max depth: {max_depth}")
# COMMAND ----------
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import current_timestamp

# Define schema for DBFS files
schema = StructType([
    StructField("path", StringType(), True),
    StructField("name", StringType(), True),
    StructField("size", StringType(), True),
    StructField("modificationTime", StringType(), True),
    StructField("isDir", StringType(), True)
])


# Paths to exclude
exclude_paths = [
    "Volume/",
    "Volumes/",
    "volume/",
    "volumes/",
    "databricks-datasets/",
    "databricks-results/"
]

def dbfs_iterator(path="dbfs:/", max_depth=None):
    """
    Iterator that yields DBFS files and directories in batches.

    Args:
        path: Starting path to list (default: "dbfs:/")
        max_depth: Maximum recursion depth (None for unlimited)

    Yields:
        Tuples of (path, name, size, modificationTime, isDir)
    """
    try:
        entries = dbutils.fs.ls(path)
        for entry in entries:
            # Skip excluded paths
            if any(exclude_path == entry.name for exclude_path in exclude_paths):
                continue

            # Yield current entry
            yield (
                entry.path,
                entry.name,
                str(entry.size),
                str(entry.modificationTime),
                str(entry.isDir())
            )

            # Recursively process directories if not at max depth
            if entry.isDir() and (max_depth is None or max_depth > 0):
                # Decrease max_depth for recursive calls
                next_max_depth = None if max_depth is None else max_depth - 1
                for item in dbfs_iterator(entry.path, next_max_depth):
                    yield item

    except Exception as e:
        print(f"Error reading path {path}: {e}")


def save_batch_to_delta(batch, table_name, offset):
    """
    Save a batch of files to a Delta table.

    Args:
        batch: List of file tuples
        table_name: Name of the Delta table
        offset: Starting index for this batch
    """
    # Create DataFrame from batch
    df = spark.createDataFrame(batch, schema)

    # Add timestamp
    df = df.withColumn("updated_at", current_timestamp())

    # Save to Delta table
    if offset == 0:
        # First batch - create table
        df.write.format("delta").mode("overwrite").saveAsTable(table_name)
    else:
        # Append to existing table
        df.write.format("delta").mode("append").saveAsTable(table_name)

    print(f"offset: {offset}")

def process_dbfs_in_batches(batch_size=1000, output_table=f"{catalog_schema}.dbfs_files"):
    """
    Process DBFS files in batches and save to a Delta table.

    Args:
        batch_size: Number of files to process in each batch
        output_table: Name of the output Delta table
    """
    batch = []
    total_processed = 0

    # Create iterator
    iterator = dbfs_iterator(max_depth=max_depth)

    # Process in batches
    for item in iterator:
        batch.append(item)
        total_processed += 1

        # When batch is full, save it
        if len(batch) >= batch_size:
            save_batch_to_delta(batch, output_table, total_processed - len(batch))
            batch = []
            print(f"Processed {total_processed} files so far")

    # Save any remaining items
    if batch:
        save_batch_to_delta(batch, output_table, total_processed - len(batch))

    print(f"Completed processing {total_processed} files")
# COMMAND ----------
# Run the batch processor
process_dbfs_in_batches(batch_size=1000, output_table=f"{catalog_schema}.dbfs_files")
