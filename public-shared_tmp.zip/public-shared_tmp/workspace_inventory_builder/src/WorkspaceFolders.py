# Databricks notebook source
%pip install --upgrade databricks-sdk
dbutils.library.restartPython()
# COMMAND ----------
dbutils.widgets.removeAll()
# COMMAND ----------
dbutils.widgets.text("max_depth", "3")
dbutils.widgets.text("catalog_schema", "shared.bigc")
# COMMAND ----------
widgets = dbutils.widgets.getAll()
max_depth = int(widgets["max_depth"])
catalog_schema = widgets["catalog_schema"]
print(f"Max depth: {max_depth}")
# COMMAND ----------
from pyspark.sql.types import StructType, StructField, StringType, LongType, TimestampType
from pyspark.sql.functions import current_timestamp, from_unixtime
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.workspace import ObjectType

# Define schema for workspace items
schema = StructType([
    StructField("path", StringType(), True),
    StructField("object_type", StringType(), True),
    StructField("language", StringType(), True),
    StructField("object_id", LongType(), True),
    StructField("resource_id", StringType(), True),
    StructField("created_at", LongType(), True),
    StructField("modified_at", LongType(), True),
    StructField("size", LongType(), True),
    StructField("workspace_id", StringType(), True)
])

# Paths to exclude
exclude_paths = [
]

def workspace_iterator(path="/", max_depth=None, current_depth=0):
    """
    Iterator that yields workspace items in batches.

    Args:
        path: Starting path to list (default: "/")
        max_depth: Maximum recursion depth (None for unlimited)
        current_depth: Current recursion depth

    Yields:
        Tuples of (path, object_type, language, object_id, resource_id, created_at, modified_at, size, workspace_id)
    """
    try:
        w = WorkspaceClient()
        workspace_id = w.get_workspace_id()

        print(f"Listing path: {path} at depth {current_depth}")
        entries = w.workspace.list(path=path)

        for entry in entries:
            # Skip excluded paths
            if any(exclude_path in entry.path for exclude_path in exclude_paths):
                continue

            if entry.object_type == ObjectType.DIRECTORY:
                # Yield current entry if it's a directory
                yield (
                    entry.path,
                    "DIRECTORY",
                    entry.language,
                    entry.object_id,
                    entry.resource_id,
                    entry.created_at,
                    entry.modified_at,
                    entry.size,
                    workspace_id
                )

            # Recursively process directories if not at max depth
            if entry.object_type == ObjectType.DIRECTORY and (max_depth is None or current_depth < max_depth):
                # Recursively process the directory
                for item in workspace_iterator(entry.path, max_depth, current_depth + 1):
                    yield item

    except Exception as e:
        print(f"Error reading path {path}: {e}")
        import traceback
        print(traceback.format_exc())

def save_batch_to_delta(batch, table_name, offset):
    """
    Save a batch of workspace items to a Delta table.

    Args:
        batch: List of workspace item tuples
        table_name: Name of the Delta table
        offset: Starting index for this batch
    """
    # Create DataFrame from batch
    df = spark.createDataFrame(batch, schema)

    # Add timestamp
    df = df.withColumn("updated_at", current_timestamp())

    # Save to Delta table
    if offset == 0:
        # First batch - create table
        df.write.format("delta").mode("overwrite").saveAsTable(table_name)
    else:
        # Append to existing table
        df.write.format("delta").mode("append").saveAsTable(table_name)

    print(f"offset: {offset}")

def process_workspace_in_batches(batch_size=1000, output_table=f"{catalog_schema}.workspace_folders"):
    """
    Process workspace items in batches and save to a Delta table.

    Args:
        batch_size: Number of items to process in each batch
        output_table: Name of the output Delta table
    """
    batch = []
    total_processed = 0

    # Create iterator with initial depth 0
    iterator = workspace_iterator(max_depth=max_depth, current_depth=0)

    # Process in batches
    for item in iterator:
        batch.append(item)
        total_processed += 1

        # When batch is full, save it
        if len(batch) >= batch_size:
            save_batch_to_delta(batch, output_table, total_processed - len(batch))
            batch = []
            print(f"Processed {total_processed} items so far")

    # Save any remaining items
    if batch:
        save_batch_to_delta(batch, output_table, total_processed - len(batch))

    print(f"Completed processing {total_processed} items")
# COMMAND ----------
# Run the batch processor
process_workspace_in_batches(batch_size=1000, output_table=f"{catalog_schema}.workspace_folders")
