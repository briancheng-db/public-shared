# Databricks notebook source
%pip install --upgrade databricks-sdk
dbutils.library.restartPython()
# COMMAND ----------

dbutils.widgets.text("catalog_schema", "shared.workspace_inventory")

catalog_schema = dbutils.widgets.get("catalog_schema")
# COMMAND ----------

from databricks.sdk import WorkspaceClient
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import current_timestamp

w = WorkspaceClient()
warehouse_g_config = w.warehouses.get_workspace_warehouse_config()

# Define schema
schema = StructType([
    StructField("global_config", StringType(), True),
    StructField("workspace_id", StringType(), True),
])

# Convert mount data to list of tuples
data = [(warehouse_g_config.as_dict(), w.get_workspace_id())]
df = spark.createDataFrame(data, schema)

df = df.withColumn("updated_at", current_timestamp())

df.write.option("mergeSchema", "true").mode("overwrite").saveAsTable(f"{catalog_schema}.warehouse_global_config")