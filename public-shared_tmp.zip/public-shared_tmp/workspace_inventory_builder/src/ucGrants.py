# Databricks notebook source

# COMMAND ----------

dbutils.widgets.text("catalog_schema", "shared.workspace_inventory")
# COMMAND ----------
catalog_schema = dbutils.widgets.get("catalog_schema")
# COMMAND ----------

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import catalog
from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, StringType, ArrayType

def get_all_grants():
    w = WorkspaceClient()
    grant_rows = []

    # Define the types of objects and their corresponding tables
    object_types = [
        (catalog.SecurableType.TABLE, "tables", "table"),
        (catalog.SecurableType.SCHEMA, "schemas", "schema"),
        (catalog.SecurableType.CATALOG, "catalogs", "catalog")
    ]

    # Process each type of object
    for securable_type, table_name, object_type in object_types:
        # Get all objects of this type
        sql = f"""
        SELECT *
        FROM {catalog_schema}.{table_name}
        """
        objects_df = spark.sql(sql)

        # For each object, get its grants
        for obj_row in objects_df.collect():
            full_name = obj_row.full_name

            try:
                grants = w.grants.get_effective(
                    securable_type=securable_type,
                    full_name=full_name,
                )

                # Group privileges by principal
                principal_privileges = {}
                for grant in grants.privilege_assignments:
                    principal = grant.principal
                    if principal not in principal_privileges:
                        principal_privileges[principal] = []
                    principal_privileges[principal].extend([p.privilege for p in grant.privileges])

                # Create rows for each principal
                for principal, privileges in principal_privileges.items():
                    grant_rows.append(Row(
                        object_type=object_type,
                        object_name=full_name,
                        principal=principal,
                        privileges=privileges
                    ))

            except Exception as e:
                print(f"Error getting grants for {full_name}: {str(e)}")

    # Define schema for the DataFrame
    schema = StructType([
        StructField("object_type", StringType(), True),
        StructField("object_name", StringType(), True),
        StructField("principal", StringType(), True),
        StructField("privileges", ArrayType(StringType()), True)
    ])

    # Create DataFrame from the rows
    return spark.createDataFrame(grant_rows, schema)

# Get all grants DataFrame
grants_df = get_all_grants()

# Save the results
grants_df.write.mode("overwrite").saveAsTable(f"{catalog_schema}.uc_grants")
