# Databricks notebook source
%pip install --upgrade databricks-sdk
dbutils.library.restartPython()
# COMMAND ----------

dbutils.widgets.text("catalog_schema", "shared.workspace_inventory")

catalog_schema = dbutils.widgets.get("catalog_schema")
# COMMAND ----------

from databricks.sdk import WorkspaceClient
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import current_timestamp, lit

def write_to_table(df, catalog_schema, table_name, mode="append", options=None):
    """
    Write DataFrame to table with specified configuration

    Args:
        df: DataFrame to write
        catalog_schema: Catalog and schema name
        table_name: Target table name
        mode: Write mode (default: append)
        options: Additional write options (default: None)
    """
    df = df.withColumn("updated_at", current_timestamp())

    writer = df.write
    if options:
        writer = writer.options(**options)

    writer.option("mergeSchema", "true").mode(mode).saveAsTable(f"{catalog_schema}.{table_name}")

w = WorkspaceClient()

sql = f"""
select
    id
from
    {catalog_schema}.legacy_dashboards
"""
schema = StructType([
    StructField("id", StringType(), True),
    StructField("options", StringType(), True),
    StructField("visualization", StringType(), True),
    StructField("width", StringType(), True),
    StructField("workspace_id", StringType(), True),
    StructField("dashboard_id", StringType(), True),
])

df = spark.sql(sql)
dashboard_ids = df.select("id").distinct().collect()
workspace_id = w.get_workspace_id()

# Initialize empty list for batch processing
data = []
batch_size = 100
first_batch = True
table_name = "legacy_dashboards_widgets_visualizations"

for dashboard_id in dashboard_ids:
    d = w.dashboards.get(dashboard_id['id'])

    for widget in d.widgets:
        widget_dict = widget.as_dict()
        data.append((
            widget_dict.get('id', None),
            widget_dict.get('options', None),
            widget_dict.get('visualization', None),
            widget_dict.get('width', None),
            workspace_id,
            dashboard_id['id']
        ))

        # When we reach batch_size, write to table
        if len(data) >= batch_size:
            res_df = spark.createDataFrame(data, schema)
            write_mode = "overwrite" if first_batch else "append"
            write_to_table(
                df=res_df,
                catalog_schema=catalog_schema,
                table_name=table_name,
                mode=write_mode,
                options={"mergeSchema": "true"}
            )

            # Clear the data list and update first_batch flag
            data = []
            first_batch = False

# Write any remaining data
if data:
    res_df = spark.createDataFrame(data, schema)
    write_mode = "overwrite" if first_batch else "append"
    write_to_table(
        df=res_df,
        catalog_schema=catalog_schema,
        table_name=table_name,
        mode=write_mode,
        options={"mergeSchema": "true"}
    )
