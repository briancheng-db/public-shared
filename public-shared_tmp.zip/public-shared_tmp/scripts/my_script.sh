#!/bin/bash
echo "Hello from script"
ls -l
# install the Databricks CLI, version v0.218.0 or above

# To find the version of the Databricks CLI that is installed
echo "Databricks CLI Version:"
databricks --version