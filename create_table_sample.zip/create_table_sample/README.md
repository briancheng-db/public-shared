# Create Databricks Table

This Terraform code creates a managed table in Databricks Unity Catalog.

## Prerequisites

- Terraform installed
- Databricks workspaces
- Unity Catalogs and Schemas
- Azure Service Principal

## Usage

1.  **Navigate to the `create_table` directory.**
    ```bash
    cd create_table
    ```

2.  **Create a `terraform.tfvars` file.**
    You can copy the sample file:
    ```bash
    cp terraform.tfvars_sample terraform.tfvars
    ```
    Update the `terraform.tfvars` file with your specific values for the following variables:
    - `databricks_workspace_url`
    - `databricks_workspace_resource_id`
    - `azure_sp_client_id`
    - `azure_sp_client_secret`
    - `azure_sp_tenant_id`
    - `dabpoc_catalog_name`
    - `dabpoc_schema_name`

4.  **Initialize Terraform.**
    ```bash
    terraform init
    ```

5.  **Plan the deployment.**
    ```bash
    terraform plan
    ```

6.  **Apply the configuration.**
    ```bash
    terraform apply
    ```

This will create a table named `member_pii_raw` in the specified catalog and schema.
